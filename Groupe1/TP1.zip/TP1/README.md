# Bibliothèques
* stdio.h
*

# Références
* [le cours](https://johnsamuel.info/fr/enseignement/cours/2025/PLP/cours1.html)  
*

# Difficulté
* prise en main et installation de gcc

# Commentaires
* 
* 

