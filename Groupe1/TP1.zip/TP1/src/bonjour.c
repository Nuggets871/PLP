#include <stdio.h>

int main() {
    printf("Bonjour");
    return 0;
}
