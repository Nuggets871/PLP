# Bibliothèques
* stdio.h
* string.h
* stdbool.h

# Références
* [le cours 1](https://johnsamuel.info/fr/enseignement/cours/2025/PLP/cours1.html)
* [le cours 2](https://johnsamuel.info/fr/enseignement/cours/2025/PLP/cours2.html)

# Difficulté
* comment utiliser les structures
* avec l'habitude des langages plus avancés j'ai souvent le reflexe d'utiliser des méthodes ou des raccourcis mais ils n'existent pas en C

# Commentaires
* On avait déjà les bases grâce à nos années de BUT informatique mais c'était de loin souvenirs, les exercices nous ont permis de bien nous rememorer ça et de développer nos connaissances.
* 

